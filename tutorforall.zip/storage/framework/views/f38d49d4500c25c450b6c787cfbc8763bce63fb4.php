<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>welcome email</title>
</head>
<body>
<p>
    Hi, <strong><?php echo e(ucwords($user['firstName'])); ?></strong>
    Welcome to tutor4all.com. Thank you for sign-up with us..
    Please follow the link below to verify your email address
    <br />
    User Name: <?php echo e($user['phone']); ?>

    <br />
    User Name: <?php echo e($user['password']); ?>

    <br />
    <?php echo e(URL::to('register/verify/' . $confirmation_code)); ?>

</p>
</body>
</html>
