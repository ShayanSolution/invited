<?php
// config/user-constants.php
return [
    'TUTOR_ROLE_ID' => 2,
    'STUDENT_ROLE_ID' => 3,
    'ADMIN_EMAIL' => 'admin@site.com'
];
