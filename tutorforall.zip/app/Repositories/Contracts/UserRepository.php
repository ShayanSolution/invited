<?php //app/Repositories/Contracts/UserRepository.php

namespace App\Repositories\Contracts;

interface UserRepository extends BaseRepository
{
}